const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
    user: 'libromx.gestiondev@gmail.com',
    pass: 'jjdf mqnw mjpy ukdh'
    }
  });
  
  module.exports = transporter;