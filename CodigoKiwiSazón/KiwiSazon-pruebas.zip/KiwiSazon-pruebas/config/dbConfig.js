module.exports = {
    url: 'mongodb+srv://Jorge:Jorge01@cluster0.tbdkk.mongodb.net/DB_Kiwisazon', // Cambia esto por la URL de tu base de datos
};