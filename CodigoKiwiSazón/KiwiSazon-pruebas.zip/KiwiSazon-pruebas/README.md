# KiwiSazon
Repositorio de documentación para KiwiSazon
# # Objetivo 
Crear una aplicación web donde los amantes de la cocina puedan compartir y descubrir recetas. Con la finalidad de descubrir e interactuar con personas apasionadas con la gastronomía. 
